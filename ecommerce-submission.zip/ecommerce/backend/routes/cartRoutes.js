const express = require('express');
const router = express.Router();
// Cart is managed client-side (localStorage/context). 
// This route handles server-side cart sync for logged-in users.
const { protect } = require('../middleware/authMiddleware');
const User = require('../models/User');

// For simplicity, cart is stored in user document
// GET /api/cart
router.get('/', protect, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('cart');
    res.json(user.cart || []);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST /api/cart/sync
router.post('/sync', protect, async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.user._id, { cart: req.body.cart });
    res.json({ message: 'Cart synced' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;
