// Run: node config/seed.js
const mongoose = require('mongoose');
const dotenv = require('dotenv');
const User = require('../models/User');
const Product = require('../models/Product');

dotenv.config();
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/ecommerce';

const products = [
  { name: 'Wireless Headphones', description: 'Premium noise-cancelling over-ear headphones with 30hr battery.', price: 2999, category: 'Electronics', stock: 50, imageUrl: 'https://via.placeholder.com/300?text=Headphones' },
  { name: 'Running Shoes', description: 'Lightweight and breathable running shoes for all terrains.', price: 1499, category: 'Footwear', stock: 80, imageUrl: 'https://via.placeholder.com/300?text=Shoes' },
  { name: 'Leather Wallet', description: 'Slim genuine leather bifold wallet with RFID protection.', price: 599, category: 'Accessories', stock: 120, imageUrl: 'https://via.placeholder.com/300?text=Wallet' },
  { name: 'Smart Watch', description: 'Feature-rich smartwatch with health tracking and GPS.', price: 4999, category: 'Electronics', stock: 30, imageUrl: 'https://via.placeholder.com/300?text=Watch' },
  { name: 'Coffee Maker', description: 'Programmable 12-cup coffee maker with thermal carafe.', price: 1899, category: 'Kitchen', stock: 40, imageUrl: 'https://via.placeholder.com/300?text=Coffee' },
  { name: 'Yoga Mat', description: 'Non-slip eco-friendly yoga mat with alignment lines.', price: 799, category: 'Sports', stock: 60, imageUrl: 'https://via.placeholder.com/300?text=Yoga' }
];

async function seed() {
  await mongoose.connect(MONGO_URI);
  await User.deleteMany();
  await Product.deleteMany();
  await User.create([
    { name: 'Admin User', email: 'admin@shop.com', password: 'admin123', role: 'admin' },
    { name: 'John Doe', email: 'john@example.com', password: 'user123', role: 'user' }
  ]);
  await Product.insertMany(products);
  console.log('Seeded! Admin: admin@shop.com/admin123 | User: john@example.com/user123');
  process.exit();
}
seed().catch(err => { console.error(err); process.exit(1); });
