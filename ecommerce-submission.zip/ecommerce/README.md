# 🛒 ShopZone – E-Commerce Web Application

A full-stack e-commerce application built with **React**, **Node.js/Express**, and **MongoDB**.

---

## 📁 Project Structure
```
ecommerce/
├── backend/          # Node.js + Express REST API
│   ├── models/       # Mongoose models (User, Product, Order)
│   ├── routes/       # API routes (auth, products, orders, cart)
│   ├── middleware/   # JWT auth middleware
│   ├── config/       # DB seed script
│   └── server.js     # Entry point
└── frontend/         # React application
    └── src/
        ├── context/  # AuthContext, CartContext
        ├── components/ # Navbar, ProductCard, PrivateRoute
        └── pages/    # All page components
```

---

## ⚙️ Setup & Installation

### Prerequisites
- Node.js v16+
- MongoDB (local or Atlas)

### Backend Setup
```bash
cd backend
npm install
cp .env.example .env     # Edit with your MongoDB URI & JWT secret
node config/seed.js      # Seed demo data
npm run dev              # Starts on port 5000
```

### Frontend Setup
```bash
cd frontend
npm install
npm start                # Starts on port 3000
```

---

## 🔐 Demo Credentials
| Role  | Email              | Password  |
|-------|--------------------|-----------|
| Admin | admin@shop.com     | admin123  |
| User  | john@example.com   | user123   |

---

## ✅ Features Implemented

### User Features
- ✅ User Registration & Login (JWT Authentication)
- ✅ Role-based access (Admin / User)
- ✅ Product catalog with search & category filter
- ✅ Product detail page with reviews & ratings
- ✅ Add to cart, update quantity, remove items
- ✅ Checkout with shipping address & payment method
- ✅ Order placement with GST & shipping calculation
- ✅ My Orders page with order tracking
- ✅ Profile management

### Admin Features
- ✅ Admin Dashboard with revenue stats
- ✅ Add / Delete products
- ✅ View & update all orders (status management)
- ✅ Low stock indicators

---

## 🗃️ Database Schema

### User
- name, email, password (hashed), role (admin/user), address

### Product
- name, description, price, category, stock, imageUrl, reviews[], rating

### Order
- user, items[], shippingAddress, paymentMethod, prices, status, isPaid

---

## 🔌 API Endpoints

| Method | Endpoint                  | Access  | Description           |
|--------|---------------------------|---------|----------------------|
| POST   | /api/auth/register        | Public  | Register user         |
| POST   | /api/auth/login           | Public  | Login                 |
| GET    | /api/auth/profile         | Private | Get profile           |
| PUT    | /api/auth/profile         | Private | Update profile        |
| GET    | /api/products             | Public  | List products         |
| GET    | /api/products/:id         | Public  | Get product           |
| POST   | /api/products             | Admin   | Create product        |
| PUT    | /api/products/:id         | Admin   | Update product        |
| DELETE | /api/products/:id         | Admin   | Delete product        |
| POST   | /api/products/:id/reviews | Private | Add review            |
| POST   | /api/orders               | Private | Place order           |
| GET    | /api/orders/my            | Private | My orders             |
| GET    | /api/orders               | Admin   | All orders            |
| PUT    | /api/orders/:id/status    | Admin   | Update order status   |

---

## 🛠️ Tech Stack
- **Frontend**: React 18, React Router v6, Axios, Context API
- **Backend**: Node.js, Express.js, JWT, bcryptjs
- **Database**: MongoDB with Mongoose ODM
- **Auth**: JWT (JSON Web Tokens) + bcrypt password hashing
