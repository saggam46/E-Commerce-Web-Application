import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const s = {
  card: { background: '#fff', borderRadius: '10px', overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.08)', transition: 'transform 0.2s', cursor: 'pointer' },
  img: { width: '100%', height: '180px', objectFit: 'cover', background: '#f0f0f0' },
  body: { padding: '1rem' },
  name: { fontWeight: '600', fontSize: '1rem', marginBottom: '4px' },
  category: { color: '#888', fontSize: '0.8rem', marginBottom: '8px' },
  price: { color: '#e94560', fontWeight: 'bold', fontSize: '1.1rem' },
  btn: { marginTop: '10px', width: '100%', padding: '8px', background: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '6px', fontWeight: '600' },
  outOfStock: { color: '#ccc', fontSize: '0.8rem' }
};

export default function ProductCard({ product }) {
  const { addToCart } = useCart();
  return (
    <div style={s.card}>
      <Link to={`/products/${product._id}`}>
        <img src={product.imageUrl || 'https://via.placeholder.com/300'} alt={product.name} style={s.img} />
        <div style={s.body}>
          <div style={s.name}>{product.name}</div>
          <div style={s.category}>{product.category}</div>
          <div style={s.price}>₹{product.price.toLocaleString()}</div>
          {product.stock === 0 && <div style={s.outOfStock}>Out of Stock</div>}
        </div>
      </Link>
      <div style={{ padding: '0 1rem 1rem' }}>
        <button style={{ ...s.btn, opacity: product.stock === 0 ? 0.5 : 1 }}
          disabled={product.stock === 0}
          onClick={() => addToCart(product)}>
          {product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
        </button>
      </div>
    </div>
  );
}
