import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <p>© 2026 <strong>ShopHub</strong> — E-Commerce Web Application | Built with React & Node.js</p>
    </footer>
  );
}
