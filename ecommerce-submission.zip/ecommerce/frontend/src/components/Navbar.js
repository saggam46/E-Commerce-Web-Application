import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const styles = {
  nav: { background: '#1a1a2e', color: '#fff', padding: '0 2rem', display: 'flex', alignItems: 'center', justifyContent: 'space-between', height: '60px', boxShadow: '0 2px 8px rgba(0,0,0,0.3)' },
  logo: { fontSize: '1.4rem', fontWeight: 'bold', color: '#e94560' },
  links: { display: 'flex', gap: '1.5rem', alignItems: 'center', listStyle: 'none' },
  link: { color: '#ccc', fontSize: '0.95rem', transition: 'color 0.2s' },
  cartBadge: { background: '#e94560', color: '#fff', borderRadius: '50%', padding: '2px 6px', fontSize: '0.7rem', marginLeft: '4px' },
  btn: { background: '#e94560', color: '#fff', border: 'none', padding: '6px 14px', borderRadius: '4px', fontSize: '0.85rem' }
};

export default function Navbar() {
  const { user, logout } = useAuth();
  const { totalItems } = useCart();
  const navigate = useNavigate();

  return (
    <nav style={styles.nav}>
      <Link to="/" style={styles.logo}>🛒 ShopZone</Link>
      <ul style={styles.links}>
        <li><Link to="/products" style={styles.link}>Products</Link></li>
        <li>
          <Link to="/cart" style={styles.link}>
            Cart <span style={styles.cartBadge}>{totalItems}</span>
          </Link>
        </li>
        {user ? (
          <>
            <li><Link to="/orders" style={styles.link}>My Orders</Link></li>
            <li><Link to="/profile" style={styles.link}>{user.name}</Link></li>
            {user.role === 'admin' && <li><Link to="/admin" style={{ ...styles.link, color: '#ffd700' }}>Admin</Link></li>}
            <li><button style={styles.btn} onClick={() => { logout(); navigate('/'); }}>Logout</button></li>
          </>
        ) : (
          <>
            <li><Link to="/login" style={styles.link}>Login</Link></li>
            <li><Link to="/register"><button style={styles.btn}>Register</button></Link></li>
          </>
        )}
      </ul>
    </nav>
  );
}
