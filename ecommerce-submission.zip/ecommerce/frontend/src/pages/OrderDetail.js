import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const STEPS = ['Pending', 'Processing', 'Shipped', 'Delivered'];

export default function OrderDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [order, setOrder] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`${API_URL}/orders/${id}`)
      .then(res => setOrder(res.data.order))
      .catch(() => navigate('/orders'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleCancel = async () => {
    if (!window.confirm('Cancel this order?')) return;
    try {
      await axios.put(`${API_URL}/orders/${id}/cancel`);
      toast.success('Order cancelled');
      const res = await axios.get(`${API_URL}/orders/${id}`);
      setOrder(res.data.order);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Cannot cancel order');
    }
  };

  if (loading) return <div className="loading"><div className="spinner"></div></div>;
  if (!order) return null;

  const currentStep = order.orderStatus === 'Cancelled' ? -1 : STEPS.indexOf(order.orderStatus);

  return (
    <div className="container" style={{ padding: '32px 20px', maxWidth: '800px' }}>
      <button onClick={() => navigate('/orders')} className="btn btn-outline btn-sm" style={{ marginBottom: '24px' }}>← Back to Orders</button>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '28px' }}>
        <div>
          <h1 style={{ fontSize: '28px', fontWeight: '900' }}>Order #{order._id.slice(-8).toUpperCase()}</h1>
          <p style={{ color: '#6c757d' }}>Placed on {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
        </div>
        <span className={`order-status status-${order.orderStatus.toLowerCase()}`}>{order.orderStatus}</span>
      </div>

      {/* Order Tracking */}
      {order.orderStatus !== 'Cancelled' && (
        <div className="card" style={{ padding: '28px', marginBottom: '20px' }}>
          <h3 style={{ marginBottom: '24px', fontWeight: '700' }}>📍 Order Tracking</h3>
          <div style={{ display: 'flex', justifyContent: 'space-between', position: 'relative' }}>
            <div style={{ position: 'absolute', top: '20px', left: '10%', right: '10%', height: '4px', background: '#e0e0e0', zIndex: 0 }}>
              <div style={{ height: '100%', background: '#e94560', width: `${(currentStep / (STEPS.length - 1)) * 100}%`, transition: 'width 0.5s' }}></div>
            </div>
            {STEPS.map((step, i) => (
              <div key={step} style={{ textAlign: 'center', zIndex: 1, flex: 1 }}>
                <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: i <= currentStep ? '#e94560' : '#e0e0e0', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', margin: '0 auto 8px', fontWeight: '700', fontSize: '16px' }}>
                  {i <= currentStep ? '✓' : i + 1}
                </div>
                <div style={{ fontSize: '12px', fontWeight: '600', color: i <= currentStep ? '#e94560' : '#aaa' }}>{step}</div>
              </div>
            ))}
          </div>
          {order.trackingNumber && <p style={{ marginTop: '16px', fontSize: '14px', color: '#6c757d' }}>Tracking #: <strong>{order.trackingNumber}</strong></p>}
        </div>
      )}

      {/* Order Items */}
      <div className="card" style={{ padding: '24px', marginBottom: '20px' }}>
        <h3 style={{ marginBottom: '16px', fontWeight: '700' }}>🛍 Order Items</h3>
        {order.orderItems.map(item => (
          <div key={item._id} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 0', borderBottom: '1px solid #f0f0f0' }}>
            <div>
              <div style={{ fontWeight: '600' }}>{item.name}</div>
              <div style={{ fontSize: '13px', color: '#6c757d' }}>₹{item.price?.toLocaleString()} × {item.quantity}</div>
            </div>
            <div style={{ fontWeight: '800', color: '#e94560' }}>₹{(item.price * item.quantity).toLocaleString()}</div>
          </div>
        ))}
        <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '2px solid #e0e0e0' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '14px' }}><span>Subtotal</span><span>₹{order.itemsPrice?.toFixed(2)}</span></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '14px' }}><span>Shipping</span><span>{order.shippingPrice === 0 ? 'FREE' : `₹${order.shippingPrice}`}</span></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6px', fontSize: '14px' }}><span>GST</span><span>₹{order.taxPrice?.toFixed(2)}</span></div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontWeight: '900', fontSize: '20px', color: '#e94560', marginTop: '8px' }}><span>Total</span><span>₹{order.totalPrice?.toFixed(2)}</span></div>
        </div>
      </div>

      {/* Shipping & Payment Info */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '20px', marginBottom: '20px' }}>
        <div className="card" style={{ padding: '20px' }}>
          <h4 style={{ marginBottom: '12px', fontWeight: '700' }}>📦 Shipping Address</h4>
          <p style={{ fontSize: '14px', color: '#495057', lineHeight: '1.8' }}>
            {order.shippingAddress.street}<br />
            {order.shippingAddress.city}, {order.shippingAddress.state}<br />
            {order.shippingAddress.zipCode}, {order.shippingAddress.country}
          </p>
        </div>
        <div className="card" style={{ padding: '20px' }}>
          <h4 style={{ marginBottom: '12px', fontWeight: '700' }}>💳 Payment</h4>
          <p style={{ fontSize: '14px', color: '#495057' }}><strong>Method:</strong> {order.paymentMethod}</p>
          <p style={{ fontSize: '14px', marginTop: '6px' }}>
            <strong>Status:</strong>{' '}
            <span style={{ color: order.isPaid ? 'green' : '#e94560' }}>{order.isPaid ? `✅ Paid on ${new Date(order.paidAt).toLocaleDateString()}` : '⏳ Pending'}</span>
          </p>
        </div>
      </div>

      {/* Cancel button */}
      {['Pending', 'Processing'].includes(order.orderStatus) && (
        <button onClick={handleCancel} className="btn btn-danger">Cancel Order</button>
      )}
    </div>
  );
}
