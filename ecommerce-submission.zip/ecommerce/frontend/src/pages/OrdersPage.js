import React, { useState, useEffect } from 'react';
import axios from 'axios';

const statusColors = { Pending: '#f39c12', Processing: '#3498db', Shipped: '#9b59b6', Delivered: '#27ae60', Cancelled: '#e74c3c' };

const s = {
  container: { maxWidth: '900px', margin: '2rem auto', padding: '0 2rem' },
  title: { fontSize: '1.8rem', fontWeight: 'bold', marginBottom: '2rem' },
  card: { background: '#fff', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem', boxShadow: '0 2px 10px rgba(0,0,0,0.07)' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem', flexWrap: 'wrap', gap: '0.5rem' },
  badge: (status) => ({ background: statusColors[status] || '#888', color: '#fff', padding: '4px 12px', borderRadius: '20px', fontSize: '0.8rem', fontWeight: '600' }),
  item: { display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: '1px solid #f0f0f0', fontSize: '0.9rem' },
  total: { display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', marginTop: '0.75rem', fontSize: '1rem' },
  empty: { textAlign: 'center', padding: '4rem', color: '#888' }
};

export default function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get('/api/orders/my')
      .then(({ data }) => setOrders(data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ padding: '2rem' }}>Loading orders...</div>;

  if (orders.length === 0) return (
    <div style={s.empty}>
      <div style={{ fontSize: '4rem' }}>📦</div>
      <h2>No orders yet</h2>
      <p style={{ marginTop: '0.5rem' }}>Start shopping to see your orders here.</p>
    </div>
  );

  return (
    <div style={s.container}>
      <h1 style={s.title}>My Orders ({orders.length})</h1>
      {orders.map(order => (
        <div key={order._id} style={s.card}>
          <div style={s.header}>
            <div>
              <div style={{ fontSize: '0.8rem', color: '#888' }}>Order ID</div>
              <div style={{ fontWeight: '600', fontFamily: 'monospace' }}>{order._id.slice(-10).toUpperCase()}</div>
            </div>
            <div>
              <div style={{ fontSize: '0.8rem', color: '#888' }}>Placed on</div>
              <div>{new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</div>
            </div>
            <span style={s.badge(order.status)}>{order.status}</span>
          </div>
          {order.items.map((item, i) => (
            <div key={i} style={s.item}>
              <span>{item.name} × {item.quantity}</span>
              <span>₹{(item.price * item.quantity).toLocaleString()}</span>
            </div>
          ))}
          <div style={s.total}>
            <span>Total Paid</span>
            <span style={{ color: '#e94560' }}>₹{order.totalPrice.toLocaleString()}</span>
          </div>
          <div style={{ marginTop: '0.5rem', fontSize: '0.85rem', color: '#888' }}>
            Payment: {order.paymentMethod} · {order.isPaid ? '✅ Paid' : '⏳ Pending'}
          </div>
        </div>
      ))}
    </div>
  );
}
