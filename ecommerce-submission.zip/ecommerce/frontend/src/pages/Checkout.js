import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function Checkout() {
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [address, setAddress] = useState({ street: '', city: '', state: '', zipCode: '', country: 'India' });
  const [paymentMethod, setPaymentMethod] = useState('COD');

  const shipping = (cart.total || 0) > 500 ? 0 : 40;
  const tax = Math.round((cart.total || 0) * 0.18 * 100) / 100;
  const grandTotal = (cart.total || 0) + shipping + tax;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!cart.items?.length) { toast.error('Cart is empty'); return; }

    setLoading(true);
    try {
      const orderItems = cart.items.map(item => ({
        product: item.product._id,
        quantity: item.quantity,
      }));

      const res = await axios.post(`${API_URL}/orders`, { orderItems, shippingAddress: address, paymentMethod });
      toast.success('Order placed successfully! 🎉');
      navigate(`/orders/${res.data.order._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container" style={{ padding: '40px 20px', maxWidth: '900px' }}>
      <div className="page-header"><h1>Checkout</h1></div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 350px', gap: '32px' }}>
        <form onSubmit={handleSubmit}>
          {/* Shipping */}
          <div className="card" style={{ padding: '24px', marginBottom: '20px' }}>
            <h3 style={{ marginBottom: '20px', fontWeight: '800' }}>📦 Shipping Address</h3>
            <div className="form-group">
              <label className="form-label">Street Address</label>
              <input className="form-control" required placeholder="123 Main St, Apt 4B" value={address.street} onChange={e => setAddress(a => ({ ...a, street: e.target.value }))} />
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">City</label>
                <input className="form-control" required placeholder="Mumbai" value={address.city} onChange={e => setAddress(a => ({ ...a, city: e.target.value }))} />
              </div>
              <div className="form-group">
                <label className="form-label">State</label>
                <input className="form-control" required placeholder="Maharashtra" value={address.state} onChange={e => setAddress(a => ({ ...a, state: e.target.value }))} />
              </div>
            </div>
            <div className="form-row">
              <div className="form-group">
                <label className="form-label">PIN Code</label>
                <input className="form-control" required placeholder="400001" value={address.zipCode} onChange={e => setAddress(a => ({ ...a, zipCode: e.target.value }))} />
              </div>
              <div className="form-group">
                <label className="form-label">Country</label>
                <input className="form-control" value={address.country} onChange={e => setAddress(a => ({ ...a, country: e.target.value }))} />
              </div>
            </div>
          </div>

          {/* Payment */}
          <div className="card" style={{ padding: '24px', marginBottom: '20px' }}>
            <h3 style={{ marginBottom: '20px', fontWeight: '800' }}>💳 Payment Method</h3>
            {['COD', 'UPI', 'Card', 'NetBanking'].map(method => (
              <label key={method} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px', border: `2px solid ${paymentMethod === method ? '#e94560' : '#e0e0e0'}`, borderRadius: '8px', marginBottom: '10px', cursor: 'pointer', transition: 'all 0.2s' }}>
                <input type="radio" name="payment" value={method} checked={paymentMethod === method} onChange={() => setPaymentMethod(method)} />
                <div>
                  <div style={{ fontWeight: '600' }}>
                    {method === 'COD' ? '💵 Cash on Delivery' : method === 'UPI' ? '📱 UPI' : method === 'Card' ? '💳 Credit/Debit Card' : '🏦 Net Banking'}
                  </div>
                  <div style={{ fontSize: '12px', color: '#6c757d' }}>
                    {method === 'COD' ? 'Pay when you receive' : 'Secure online payment'}
                  </div>
                </div>
              </label>
            ))}
          </div>

          <button type="submit" className="btn btn-primary btn-lg" style={{ width: '100%' }} disabled={loading}>
            {loading ? 'Placing Order...' : `Place Order · ₹${grandTotal.toFixed(2)}`}
          </button>
        </form>

        {/* Summary */}
        <div className="order-summary" style={{ height: 'fit-content' }}>
          <h3>Order Items ({cart.itemCount})</h3>
          {cart.items?.map(item => (
            <div key={item.product?._id} style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '10px', fontSize: '13px', paddingBottom: '10px', borderBottom: '1px solid #f0f0f0' }}>
              <span>{item.product?.name} × {item.quantity}</span>
              <span style={{ fontWeight: '700' }}>₹{item.subtotal?.toLocaleString()}</span>
            </div>
          ))}
          <div className="summary-row"><span>Subtotal</span><span>₹{cart.total?.toLocaleString()}</span></div>
          <div className="summary-row"><span>Shipping</span><span style={{ color: shipping === 0 ? 'green' : '' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
          <div className="summary-row"><span>GST (18%)</span><span>₹{tax.toFixed(2)}</span></div>
          <div className="summary-row total"><span>Grand Total</span><span>₹{grandTotal.toFixed(2)}</span></div>
        </div>
      </div>
    </div>
  );
}
