import React, { useState, useEffect } from 'react';
import axios from 'axios';

const statusColors = { Pending: '#f39c12', Processing: '#3498db', Shipped: '#9b59b6', Delivered: '#27ae60', Cancelled: '#e74c3c' };

const s = {
  container: { maxWidth: '1200px', margin: '2rem auto', padding: '0 2rem' },
  title: { fontSize: '1.8rem', fontWeight: 'bold', marginBottom: '0.5rem' },
  tabs: { display: 'flex', gap: '1rem', marginBottom: '2rem', borderBottom: '2px solid #eee', paddingBottom: '1rem' },
  tab: (active) => ({ padding: '8px 20px', border: 'none', borderRadius: '6px', cursor: 'pointer', fontWeight: '600', background: active ? '#1a1a2e' : '#f0f0f0', color: active ? '#fff' : '#333' }),
  statsGrid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: '1rem', marginBottom: '2rem' },
  stat: { background: '#fff', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 2px 8px rgba(0,0,0,0.06)', textAlign: 'center' },
  statNum: { fontSize: '2rem', fontWeight: 'bold', color: '#e94560' },
  statLabel: { color: '#888', fontSize: '0.85rem', marginTop: '4px' },
  table: { width: '100%', borderCollapse: 'collapse', background: '#fff', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 2px 10px rgba(0,0,0,0.06)' },
  th: { padding: '12px 16px', background: '#1a1a2e', color: '#fff', textAlign: 'left', fontSize: '0.85rem' },
  td: { padding: '12px 16px', borderBottom: '1px solid #f0f0f0', fontSize: '0.9rem' },
  badge: (status) => ({ background: statusColors[status] || '#888', color: '#fff', padding: '3px 10px', borderRadius: '20px', fontSize: '0.75rem' }),
  form: { background: '#fff', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)', marginBottom: '2rem' },
  input: { padding: '9px', border: '1px solid #ddd', borderRadius: '6px', fontSize: '0.9rem', width: '100%', marginBottom: '0.75rem' },
  addBtn: { padding: '10px 20px', background: '#e94560', color: '#fff', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' },
  delBtn: { padding: '5px 10px', background: '#e74c3c', color: '#fff', border: 'none', borderRadius: '4px', cursor: 'pointer', fontSize: '0.8rem' },
  selectStatus: { padding: '5px', border: '1px solid #ddd', borderRadius: '4px', fontSize: '0.8rem', cursor: 'pointer' }
};

export default function AdminDashboard() {
  const [tab, setTab] = useState('products');
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [newProduct, setNewProduct] = useState({ name: '', description: '', price: '', category: '', stock: '', imageUrl: '' });
  const [msg, setMsg] = useState('');

  useEffect(() => {
    axios.get('/api/products?page=1').then(({ data }) => setProducts(data.products));
    axios.get('/api/orders').then(({ data }) => setOrders(data));
  }, []);

  const addProduct = async () => {
    try {
      const { data } = await axios.post('/api/products', { ...newProduct, price: Number(newProduct.price), stock: Number(newProduct.stock) });
      setProducts(prev => [data, ...prev]);
      setNewProduct({ name: '', description: '', price: '', category: '', stock: '', imageUrl: '' });
      setMsg('Product added!');
    } catch (err) { setMsg('Error: ' + (err.response?.data?.message || 'failed')); }
    setTimeout(() => setMsg(''), 3000);
  };

  const deleteProduct = async (id) => {
    if (!window.confirm('Delete this product?')) return;
    await axios.delete(`/api/products/${id}`);
    setProducts(prev => prev.filter(p => p._id !== id));
  };

  const updateOrderStatus = async (id, status) => {
    await axios.put(`/api/orders/${id}/status`, { status });
    setOrders(prev => prev.map(o => o._id === id ? { ...o, status } : o));
  };

  const totalRevenue = orders.filter(o => o.status !== 'Cancelled').reduce((a, o) => a + o.totalPrice, 0);

  return (
    <div style={s.container}>
      <h1 style={s.title}>Admin Dashboard</h1>
      <div style={s.statsGrid}>
        <div style={s.stat}><div style={s.statNum}>{products.length}</div><div style={s.statLabel}>Products</div></div>
        <div style={s.stat}><div style={s.statNum}>{orders.length}</div><div style={s.statLabel}>Total Orders</div></div>
        <div style={s.stat}><div style={s.statNum}>{orders.filter(o => o.status === 'Pending').length}</div><div style={s.statLabel}>Pending</div></div>
        <div style={s.stat}><div style={{ ...s.statNum, fontSize: '1.4rem' }}>₹{totalRevenue.toLocaleString()}</div><div style={s.statLabel}>Revenue</div></div>
      </div>
      <div style={s.tabs}>
        <button style={s.tab(tab === 'products')} onClick={() => setTab('products')}>📦 Products</button>
        <button style={s.tab(tab === 'orders')} onClick={() => setTab('orders')}>🧾 Orders</button>
      </div>

      {tab === 'products' && (
        <>
          <div style={s.form}>
            <h3 style={{ marginBottom: '1rem' }}>Add New Product</h3>
            {msg && <p style={{ color: '#27ae60', marginBottom: '0.5rem' }}>{msg}</p>}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
              {['name','description','price','category','stock','imageUrl'].map(f => (
                <input key={f} style={s.input} placeholder={f.charAt(0).toUpperCase() + f.slice(1)}
                  value={newProduct[f]} onChange={e => setNewProduct({...newProduct, [f]: e.target.value})} />
              ))}
            </div>
            <button style={s.addBtn} onClick={addProduct}>+ Add Product</button>
          </div>
          <table style={s.table}>
            <thead><tr>
              {['Name','Category','Price','Stock','Actions'].map(h => <th key={h} style={s.th}>{h}</th>)}
            </tr></thead>
            <tbody>
              {products.map(p => (
                <tr key={p._id}>
                  <td style={s.td}>{p.name}</td>
                  <td style={s.td}>{p.category}</td>
                  <td style={s.td}>₹{p.price.toLocaleString()}</td>
                  <td style={s.td}><span style={{ color: p.stock < 5 ? '#e74c3c' : '#27ae60', fontWeight: '600' }}>{p.stock}</span></td>
                  <td style={s.td}><button style={s.delBtn} onClick={() => deleteProduct(p._id)}>Delete</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </>
      )}

      {tab === 'orders' && (
        <table style={s.table}>
          <thead><tr>
            {['Order ID','Customer','Total','Status','Update'].map(h => <th key={h} style={s.th}>{h}</th>)}
          </tr></thead>
          <tbody>
            {orders.map(o => (
              <tr key={o._id}>
                <td style={s.td}><span style={{ fontFamily: 'monospace', fontSize: '0.8rem' }}>{o._id.slice(-8).toUpperCase()}</span></td>
                <td style={s.td}>{o.user?.name || 'N/A'}</td>
                <td style={s.td}>₹{o.totalPrice.toLocaleString()}</td>
                <td style={s.td}><span style={s.badge(o.status)}>{o.status}</span></td>
                <td style={s.td}>
                  <select style={s.selectStatus} value={o.status} onChange={e => updateOrderStatus(o._id, e.target.value)}>
                    {['Pending','Processing','Shipped','Delivered','Cancelled'].map(st => <option key={st} value={st}>{st}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
