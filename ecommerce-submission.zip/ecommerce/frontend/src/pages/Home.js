import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const CATEGORIES = ['Electronics', 'Clothing', 'Books', 'Home & Kitchen', 'Sports', 'Beauty', 'Toys'];

export default function Home() {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`${API_URL}/products?limit=8`)
      .then(res => setFeaturedProducts(res.data.products || []))
      .catch(() => {});
  }, []);

  return (
    <div>
      {/* Hero */}
      <section className="hero">
        <div>
          <h1>Welcome to <span>ShopHub</span></h1>
          <p>Discover thousands of products at unbeatable prices. Shop smarter, live better.</p>
          <div className="hero-actions">
            <Link to="/products" className="btn btn-primary btn-lg">Shop Now →</Link>
            <Link to="/register" className="btn btn-outline btn-lg">Create Account</Link>
          </div>
        </div>
      </section>

      <div className="container">
        {/* Categories */}
        <section style={{ padding: '40px 0 20px' }}>
          <h2 style={{ fontSize: '24px', fontWeight: '800', marginBottom: '20px' }}>Shop by Category</h2>
          <div style={{ display: 'flex', gap: '12px', flexWrap: 'wrap' }}>
            {CATEGORIES.map(cat => (
              <Link
                key={cat}
                to={`/products?category=${cat}`}
                style={{
                  background: 'white', padding: '12px 24px', borderRadius: '30px',
                  boxShadow: '0 2px 10px rgba(0,0,0,0.08)', fontWeight: '600', fontSize: '14px',
                  color: '#1a1a2e', transition: 'all 0.25s'
                }}
                onMouseOver={e => { e.target.style.background = '#e94560'; e.target.style.color = 'white'; }}
                onMouseOut={e => { e.target.style.background = 'white'; e.target.style.color = '#1a1a2e'; }}
              >
                {cat}
              </Link>
            ))}
          </div>
        </section>

        {/* Featured Products */}
        {featuredProducts.length > 0 && (
          <section style={{ padding: '20px 0 40px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
              <h2 style={{ fontSize: '24px', fontWeight: '800' }}>Featured Products</h2>
              <Link to="/products" className="btn btn-outline btn-sm">View All →</Link>
            </div>
            <div className="product-grid">
              {featuredProducts.map(product => (
                <div key={product._id} className="card product-card" onClick={() => navigate(`/products/${product._id}`)}>
                  <div style={{ background: '#f8f9fa', height: '180px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '60px' }}>
                    {getCategoryEmoji(product.category)}
                  </div>
                  <div className="product-card-body">
                    <div className="product-card-brand">{product.brand}</div>
                    <div className="product-card-title">{product.name}</div>
                    <div className="product-card-rating">⭐ {product.ratings?.toFixed(1) || '0.0'} ({product.numReviews})</div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      <div className="product-card-price">₹{product.price?.toLocaleString()}</div>
                      <span className={`product-card-badge ${product.stock === 0 ? 'out' : ''}`}>
                        {product.stock > 0 ? 'In Stock' : 'Out of Stock'}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Features */}
        <section style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '20px', padding: '40px 0' }}>
          {[
            { icon: '🚚', title: 'Free Shipping', desc: 'On orders above ₹500' },
            { icon: '🔒', title: 'Secure Payment', desc: 'UPI, Cards, NetBanking' },
            { icon: '↩️', title: 'Easy Returns', desc: '7-day hassle-free returns' },
            { icon: '💬', title: '24/7 Support', desc: 'Always here to help' },
          ].map(f => (
            <div key={f.title} className="card" style={{ padding: '24px', textAlign: 'center' }}>
              <div style={{ fontSize: '36px', marginBottom: '12px' }}>{f.icon}</div>
              <div style={{ fontWeight: '700', marginBottom: '4px' }}>{f.title}</div>
              <div style={{ fontSize: '13px', color: '#6c757d' }}>{f.desc}</div>
            </div>
          ))}
        </section>
      </div>
    </div>
  );
}

function getCategoryEmoji(category) {
  const map = { 'Electronics': '📱', 'Clothing': '👕', 'Books': '📚', 'Home & Kitchen': '🍳', 'Sports': '⚽', 'Beauty': '💄', 'Toys': '🧸', 'Other': '📦' };
  return map[category] || '📦';
}
