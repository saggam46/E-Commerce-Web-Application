import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const s = {
  page: { minHeight: '100vh', background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  card: { background: '#fff', padding: '2.5rem', borderRadius: '16px', width: '100%', maxWidth: '420px', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' },
  logo: { textAlign: 'center', fontSize: '2rem', marginBottom: '0.5rem' },
  title: { textAlign: 'center', fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '0.5rem' },
  sub: { textAlign: 'center', color: '#888', marginBottom: '2rem', fontSize: '0.9rem' },
  label: { display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '0.85rem', color: '#555' },
  input: { width: '100%', padding: '11px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.95rem' },
  btn: { width: '100%', padding: '13px', background: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', fontSize: '1rem', cursor: 'pointer' },
  footer: { textAlign: 'center', marginTop: '1.5rem', color: '#888', fontSize: '0.9rem' }
};

export default function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true); setError('');
    try {
      await login(form.email, form.password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    } finally { setLoading(false); }
  };

  return (
    <div style={s.page}>
      <div style={s.card}>
        <div style={s.logo}>🛒</div>
        <h1 style={s.title}>Welcome Back</h1>
        <p style={s.sub}>Sign in to your ShopZone account</p>
        <label style={s.label}>Email</label>
        <input style={s.input} type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} placeholder="you@example.com" />
        <label style={s.label}>Password</label>
        <input style={s.input} type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} placeholder="••••••••"
          onKeyDown={e => e.key === 'Enter' && handleSubmit()} />
        {error && <p style={{ color: 'red', fontSize: '0.85rem', marginBottom: '1rem' }}>{error}</p>}
        <button style={s.btn} onClick={handleSubmit} disabled={loading}>{loading ? 'Signing in...' : 'Sign In'}</button>
        <p style={s.footer}>Don't have an account? <Link to="/register" style={{ color: '#e94560' }}>Register</Link></p>
      </div>
    </div>
  );
}
