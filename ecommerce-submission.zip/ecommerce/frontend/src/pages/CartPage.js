import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const s = {
  container: { maxWidth: '1000px', margin: '2rem auto', padding: '0 2rem' },
  title: { fontSize: '1.8rem', fontWeight: 'bold', marginBottom: '2rem' },
  grid: { display: 'grid', gridTemplateColumns: '2fr 1fr', gap: '2rem', alignItems: 'start' },
  row: { display: 'flex', alignItems: 'center', gap: '1rem', background: '#fff', padding: '1rem', borderRadius: '10px', marginBottom: '1rem', boxShadow: '0 1px 6px rgba(0,0,0,0.06)' },
  img: { width: '80px', height: '80px', objectFit: 'cover', borderRadius: '8px' },
  name: { fontWeight: '600', flex: 1 },
  price: { color: '#e94560', fontWeight: 'bold' },
  qtyBtn: { width: '30px', height: '30px', border: '1px solid #ddd', borderRadius: '4px', cursor: 'pointer', background: '#f5f5f5' },
  removeBtn: { color: '#e94560', background: 'none', border: 'none', cursor: 'pointer', fontSize: '1.2rem' },
  summary: { background: '#fff', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.08)', position: 'sticky', top: '80px' },
  row2: { display: 'flex', justifyContent: 'space-between', marginBottom: '0.75rem', fontSize: '0.95rem' },
  divider: { border: 'none', borderTop: '1px solid #eee', margin: '1rem 0' },
  total: { display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '1.1rem' },
  checkoutBtn: { width: '100%', padding: '12px', background: '#e94560', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', fontSize: '1rem', marginTop: '1rem', cursor: 'pointer' },
  empty: { textAlign: 'center', padding: '4rem', color: '#888' }
};

export default function CartPage() {
  const { cart, updateQuantity, removeFromCart, totalPrice } = useCart();
  const navigate = useNavigate();
  const shipping = totalPrice > 500 ? 0 : 50;
  const tax = Math.round(totalPrice * 0.18);

  if (cart.length === 0) return (
    <div style={s.empty}>
      <div style={{ fontSize: '4rem' }}>🛒</div>
      <h2>Your cart is empty</h2>
      <Link to="/products"><button style={{ ...s.checkoutBtn, width: 'auto', padding: '10px 24px', marginTop: '1rem' }}>Browse Products</button></Link>
    </div>
  );

  return (
    <div style={s.container}>
      <h1 style={s.title}>Shopping Cart ({cart.length} items)</h1>
      <div style={s.grid}>
        <div>
          {cart.map(item => (
            <div key={item.product} style={s.row}>
              <img src={item.imageUrl || 'https://via.placeholder.com/80'} alt={item.name} style={s.img} />
              <span style={s.name}>{item.name}</span>
              <span style={s.price}>₹{item.price.toLocaleString()}</span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <button style={s.qtyBtn} onClick={() => updateQuantity(item.product, item.quantity - 1)}>−</button>
                <span>{item.quantity}</span>
                <button style={s.qtyBtn} onClick={() => updateQuantity(item.product, item.quantity + 1)}>+</button>
              </div>
              <span style={{ fontWeight: 'bold' }}>₹{(item.price * item.quantity).toLocaleString()}</span>
              <button style={s.removeBtn} onClick={() => removeFromCart(item.product)}>✕</button>
            </div>
          ))}
        </div>
        <div style={s.summary}>
          <h2 style={{ marginBottom: '1.5rem' }}>Order Summary</h2>
          <div style={s.row2}><span>Subtotal</span><span>₹{totalPrice.toLocaleString()}</span></div>
          <div style={s.row2}><span>Shipping</span><span>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
          <div style={s.row2}><span>GST (18%)</span><span>₹{tax.toLocaleString()}</span></div>
          <hr style={s.divider} />
          <div style={s.total}><span>Total</span><span>₹{(totalPrice + shipping + tax).toLocaleString()}</span></div>
          <button style={s.checkoutBtn} onClick={() => navigate('/checkout')}>Proceed to Checkout →</button>
          <Link to="/products"><p style={{ textAlign: 'center', marginTop: '1rem', color: '#888', fontSize: '0.85rem' }}>← Continue Shopping</p></Link>
        </div>
      </div>
    </div>
  );
}
