import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    axios.get(`${API_URL}/orders/my-orders`)
      .then(res => setOrders(res.data.orders || []))
      .finally(() => setLoading(false));
  }, []);

  const getStatusClass = (status) => {
    const map = { 'Pending': 'status-pending', 'Processing': 'status-processing', 'Shipped': 'status-shipped', 'Delivered': 'status-delivered', 'Cancelled': 'status-cancelled' };
    return `order-status ${map[status] || ''}`;
  };

  if (loading) return <div className="loading"><div className="spinner"></div></div>;

  return (
    <div className="container" style={{ padding: '20px' }}>
      <div className="page-header"><h1>My Orders</h1><p>{orders.length} orders total</p></div>

      {orders.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '60px' }}>
          <div style={{ fontSize: '60px', marginBottom: '16px' }}>📦</div>
          <h3>No orders yet</h3>
          <Link to="/products" className="btn btn-primary" style={{ marginTop: '16px' }}>Start Shopping</Link>
        </div>
      ) : (
        orders.map(order => (
          <div key={order._id} className="order-card">
            <div className="order-header">
              <div>
                <div className="order-id">Order #{order._id.slice(-8).toUpperCase()}</div>
                <div style={{ fontSize: '13px', color: '#6c757d' }}>
                  {new Date(order.createdAt).toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' })}
                </div>
              </div>
              <span className={getStatusClass(order.orderStatus)}>{order.orderStatus}</span>
            </div>
            <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap', marginBottom: '12px' }}>
              {order.orderItems.map(item => (
                <div key={item._id} style={{ background: '#f8f9fa', padding: '6px 12px', borderRadius: '6px', fontSize: '13px' }}>
                  {item.name} × {item.quantity}
                </div>
              ))}
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <span style={{ fontWeight: '800', color: '#e94560', fontSize: '18px' }}>₹{order.totalPrice?.toFixed(2)}</span>
                <span style={{ fontSize: '12px', color: '#6c757d', marginLeft: '8px' }}>{order.paymentMethod}</span>
              </div>
              <Link to={`/orders/${order._id}`} className="btn btn-outline btn-sm">View Details →</Link>
            </div>
          </div>
        ))
      )}
    </div>
  );
}
