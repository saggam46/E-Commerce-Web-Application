import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const s = {
  container: { maxWidth: '600px', margin: '2rem auto', padding: '0 2rem' },
  card: { background: '#fff', padding: '2rem', borderRadius: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' },
  title: { fontSize: '1.6rem', fontWeight: 'bold', marginBottom: '2rem' },
  avatar: { width: '80px', height: '80px', borderRadius: '50%', background: '#1a1a2e', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '2rem', marginBottom: '1.5rem' },
  label: { display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '0.85rem', color: '#555' },
  input: { width: '100%', padding: '11px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.95rem' },
  btn: { padding: '11px 28px', background: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', cursor: 'pointer' },
  success: { color: '#27ae60', marginBottom: '1rem' },
  roleBadge: { background: '#e94560', color: '#fff', padding: '3px 10px', borderRadius: '20px', fontSize: '0.75rem', marginLeft: '8px' }
};

export default function ProfilePage() {
  const { user, login } = useAuth();
  const [form, setForm] = useState({ name: user?.name || '', email: user?.email || '', password: '' });
  const [msg, setMsg] = useState('');

  const handleUpdate = async () => {
    try {
      const { data } = await axios.put('/api/auth/profile', form);
      setMsg('Profile updated successfully!');
      setTimeout(() => setMsg(''), 3000);
    } catch (err) {
      setMsg(err.response?.data?.message || 'Update failed');
    }
  };

  return (
    <div style={s.container}>
      <div style={s.card}>
        <h1 style={s.title}>My Profile</h1>
        <div style={s.avatar}>{user?.name?.charAt(0).toUpperCase()}</div>
        <div style={{ marginBottom: '1.5rem' }}>
          <strong>{user?.name}</strong>
          <span style={s.roleBadge}>{user?.role}</span>
          <div style={{ color: '#888', fontSize: '0.9rem', marginTop: '4px' }}>{user?.email}</div>
        </div>
        {msg && <p style={s.success}>{msg}</p>}
        <label style={s.label}>Name</label>
        <input style={s.input} value={form.name} onChange={e => setForm({...form, name: e.target.value})} />
        <label style={s.label}>Email</label>
        <input style={s.input} type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} />
        <label style={s.label}>New Password (leave blank to keep current)</label>
        <input style={s.input} type="password" value={form.password} onChange={e => setForm({...form, password: e.target.value})} placeholder="••••••••" />
        <button style={s.btn} onClick={handleUpdate}>Save Changes</button>
      </div>
    </div>
  );
}
