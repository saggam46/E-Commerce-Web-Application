import React, { useEffect, useState, useCallback } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const CATEGORIES = ['', 'Electronics', 'Clothing', 'Books', 'Home & Kitchen', 'Sports', 'Beauty', 'Toys', 'Other'];

export default function Products() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [total, setTotal] = useState(0);
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFilters] = useState({
    keyword: searchParams.get('keyword') || '',
    category: searchParams.get('category') || '',
    sort: 'newest',
  });

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    try {
      const params = { page, limit: 12, ...filters };
      const res = await axios.get(`${API_URL}/products`, { params });
      setProducts(res.data.products || []);
      setTotalPages(res.data.totalPages || 1);
      setTotal(res.data.total || 0);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [page, filters]);

  useEffect(() => { fetchProducts(); }, [fetchProducts]);

  const handleFilter = (key, value) => {
    setFilters(f => ({ ...f, [key]: value }));
    setPage(1);
  };

  const getCategoryEmoji = (cat) => {
    const map = { 'Electronics': '📱', 'Clothing': '👕', 'Books': '📚', 'Home & Kitchen': '🍳', 'Sports': '⚽', 'Beauty': '💄', 'Toys': '🧸', 'Other': '📦' };
    return map[cat] || '📦';
  };

  return (
    <div className="container">
      <div className="page-header">
        <h1>All Products</h1>
        <p>{total} products found</p>
      </div>

      {/* Filters */}
      <div className="filters-bar">
        <input
          className="form-control search-input"
          placeholder="🔍 Search products..."
          value={filters.keyword}
          onChange={e => handleFilter('keyword', e.target.value)}
        />
        <select className="filter-select" value={filters.category} onChange={e => handleFilter('category', e.target.value)}>
          {CATEGORIES.map(c => <option key={c} value={c}>{c || 'All Categories'}</option>)}
        </select>
        <select className="filter-select" value={filters.sort} onChange={e => handleFilter('sort', e.target.value)}>
          <option value="newest">Newest First</option>
          <option value="price_asc">Price: Low to High</option>
          <option value="price_desc">Price: High to Low</option>
          <option value="rating">Top Rated</option>
        </select>
      </div>

      {loading ? (
        <div className="loading"><div className="spinner"></div></div>
      ) : products.length === 0 ? (
        <div className="loading">No products found. Try different filters.</div>
      ) : (
        <>
          <div className="product-grid">
            {products.map(product => (
              <div key={product._id} className="card product-card" onClick={() => navigate(`/products/${product._id}`)}>
                <div style={{ background: '#f8f9fa', height: '180px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '70px' }}>
                  {getCategoryEmoji(product.category)}
                </div>
                <div className="product-card-body">
                  <div className="product-card-brand">{product.brand} • {product.category}</div>
                  <div className="product-card-title">{product.name}</div>
                  <div className="product-card-rating">⭐ {product.ratings?.toFixed(1) || '0.0'} ({product.numReviews} reviews)</div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div className="product-card-price">₹{product.price?.toLocaleString()}</div>
                    <span className={`product-card-badge ${product.stock === 0 ? 'out' : ''}`}>
                      {product.stock > 0 ? `${product.stock} left` : 'Out of Stock'}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div style={{ display: 'flex', justifyContent: 'center', gap: '8px', padding: '32px 0' }}>
              <button className="btn btn-outline btn-sm" disabled={page === 1} onClick={() => setPage(p => p - 1)}>← Prev</button>
              {Array.from({ length: totalPages }, (_, i) => (
                <button
                  key={i + 1}
                  className={`btn btn-sm ${page === i + 1 ? 'btn-primary' : 'btn-outline'}`}
                  onClick={() => setPage(i + 1)}
                >{i + 1}</button>
              ))}
              <button className="btn btn-outline btn-sm" disabled={page === totalPages} onClick={() => setPage(p => p + 1)}>Next →</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
