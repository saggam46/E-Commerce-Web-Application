import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const s = {
  container: { maxWidth: '1100px', margin: '2rem auto', padding: '0 2rem' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem', alignItems: 'start' },
  img: { width: '100%', borderRadius: '12px', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' },
  badge: { display: 'inline-block', background: '#f0f4ff', color: '#1a1a2e', padding: '4px 12px', borderRadius: '20px', fontSize: '0.8rem', marginBottom: '1rem' },
  title: { fontSize: '2rem', fontWeight: 'bold', marginBottom: '0.5rem' },
  price: { fontSize: '1.8rem', color: '#e94560', fontWeight: 'bold', marginBottom: '1rem' },
  desc: { color: '#555', lineHeight: '1.6', marginBottom: '1.5rem' },
  stock: { color: '#27ae60', fontWeight: '600', marginBottom: '1rem' },
  qtyRow: { display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '1.5rem' },
  qtyBtn: { width: '36px', height: '36px', border: '1px solid #ddd', borderRadius: '6px', fontSize: '1.2rem', background: '#fff', cursor: 'pointer' },
  addBtn: { padding: '12px 32px', background: '#1a1a2e', color: '#fff', border: 'none', borderRadius: '8px', fontSize: '1rem', fontWeight: 'bold', cursor: 'pointer' },
  reviewSection: { marginTop: '3rem' },
  reviewCard: { background: '#fff', border: '1px solid #eee', borderRadius: '8px', padding: '1rem', marginBottom: '1rem' },
  reviewForm: { background: '#fff', padding: '1.5rem', borderRadius: '10px', boxShadow: '0 2px 10px rgba(0,0,0,0.06)', marginBottom: '2rem' },
  input: { width: '100%', padding: '10px', border: '1px solid #ddd', borderRadius: '6px', marginBottom: '1rem', fontSize: '0.95rem' },
  submitBtn: { padding: '10px 24px', background: '#e94560', color: '#fff', border: 'none', borderRadius: '6px', fontWeight: 'bold', cursor: 'pointer' }
};

export default function ProductDetailPage() {
  const { id } = useParams();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [qty, setQty] = useState(1);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');
  const [msg, setMsg] = useState('');

  useEffect(() => {
    axios.get(`/api/products/${id}`).then(({ data }) => setProduct(data));
  }, [id]);

  const submitReview = async () => {
    try {
      await axios.post(`/api/products/${id}/reviews`, { rating, comment });
      setMsg('Review submitted!');
      const { data } = await axios.get(`/api/products/${id}`);
      setProduct(data);
    } catch (err) {
      setMsg(err.response?.data?.message || 'Error submitting review');
    }
  };

  if (!product) return <div style={{ padding: '2rem' }}>Loading...</div>;

  return (
    <div style={s.container}>
      <div style={s.grid}>
        <div>
          <img src={product.imageUrl || 'https://via.placeholder.com/500'} alt={product.name} style={s.img} />
        </div>
        <div>
          <span style={s.badge}>{product.category}</span>
          <h1 style={s.title}>{product.name}</h1>
          <div style={s.price}>₹{product.price.toLocaleString()}</div>
          <p style={s.desc}>{product.description}</p>
          <div style={s.stock}>
            {product.stock > 0 ? `✅ In Stock (${product.stock} left)` : '❌ Out of Stock'}
          </div>
          <div>⭐ {product.rating.toFixed(1)} ({product.numReviews} reviews)</div>
          {product.stock > 0 && (
            <>
              <div style={s.qtyRow}>
                <button style={s.qtyBtn} onClick={() => setQty(q => Math.max(1, q - 1))}>−</button>
                <span style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>{qty}</span>
                <button style={s.qtyBtn} onClick={() => setQty(q => Math.min(product.stock, q + 1))}>+</button>
              </div>
              <button style={s.addBtn} onClick={() => addToCart(product, qty)}>Add to Cart 🛒</button>
            </>
          )}
        </div>
      </div>

      <div style={s.reviewSection}>
        <h2 style={{ marginBottom: '1.5rem' }}>Customer Reviews</h2>
        {user && (
          <div style={s.reviewForm}>
            <h3 style={{ marginBottom: '1rem' }}>Write a Review</h3>
            <select style={s.input} value={rating} onChange={e => setRating(Number(e.target.value))}>
              {[5,4,3,2,1].map(r => <option key={r} value={r}>{r} ⭐</option>)}
            </select>
            <textarea style={{ ...s.input, height: '100px', resize: 'vertical' }}
              placeholder="Share your experience..." value={comment}
              onChange={e => setComment(e.target.value)} />
            {msg && <p style={{ color: '#27ae60', marginBottom: '0.5rem' }}>{msg}</p>}
            <button style={s.submitBtn} onClick={submitReview}>Submit Review</button>
          </div>
        )}
        {product.reviews.length === 0 ? (
          <p style={{ color: '#888' }}>No reviews yet. Be the first!</p>
        ) : (
          product.reviews.map(r => (
            <div key={r._id} style={s.reviewCard}>
              <strong>{r.name}</strong> &nbsp;
              <span style={{ color: '#f39c12' }}>{'⭐'.repeat(r.rating)}</span>
              <p style={{ color: '#555', marginTop: '4px' }}>{r.comment}</p>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
