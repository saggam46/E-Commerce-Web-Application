import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';

const NAV_LINKS = [
  { to: '/admin', label: '📊 Dashboard', end: true },
  { to: '/admin/products', label: '📦 Products' },
  { to: '/admin/orders', label: '🛒 Orders' },
  { to: '/admin/users', label: '👥 Users' },
];

export default function AdminLayout({ children, title }) {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <div className="admin-layout">
      {/* Sidebar */}
      <aside className="admin-sidebar">
        <div className="admin-sidebar-title">Admin Panel</div>
        <div style={{ padding: '0 0 20px' }}>
          <div style={{ padding: '0 20px 20px', display: 'flex', alignItems: 'center', gap: '10px' }}>
            <div style={{ width: '36px', height: '36px', background: '#e94560', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: '700', fontSize: '16px' }}>
              {user?.name?.[0]}
            </div>
            <div>
              <div style={{ fontSize: '13px', fontWeight: '600' }}>{user?.name}</div>
              <div style={{ fontSize: '11px', opacity: 0.6 }}>Administrator</div>
            </div>
          </div>

          {NAV_LINKS.map(link => (
            <NavLink key={link.to} to={link.to} end={link.end} className={({ isActive }) => `admin-nav-link${isActive ? ' active' : ''}`}>
              {link.label}
            </NavLink>
          ))}
        </div>
        <div style={{ padding: '20px', borderTop: '1px solid rgba(255,255,255,0.1)' }}>
          <NavLink to="/" className="admin-nav-link">🏪 View Store</NavLink>
          <button onClick={() => { logout(); navigate('/login'); }} style={{ background: 'none', border: 'none', color: 'rgba(255,255,255,0.6)', padding: '12px 20px', cursor: 'pointer', width: '100%', textAlign: 'left', fontSize: '14px' }}>
            🚪 Logout
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="admin-content">
        <div style={{ marginBottom: '24px' }}>
          <h1 style={{ fontSize: '28px', fontWeight: '900' }}>{title}</h1>
        </div>
        {children}
      </div>
    </div>
  );
}
