import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import AdminLayout from './AdminLayout';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';
const STATUSES = ['', 'Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'];

export default function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState('');
  const [updating, setUpdating] = useState(null);

  const fetchOrders = () => {
    setLoading(true);
    const params = filterStatus ? { status: filterStatus } : {};
    axios.get(`${API_URL}/orders`, { params }).then(res => {
      setOrders(res.data.orders || []);
    }).finally(() => setLoading(false));
  };

  useEffect(() => { fetchOrders(); }, [filterStatus]);

  const handleStatusUpdate = async (orderId, newStatus, trackingNumber) => {
    setUpdating(orderId);
    try {
      await axios.put(`${API_URL}/orders/${orderId}/status`, { orderStatus: newStatus, trackingNumber });
      toast.success('Order status updated!');
      fetchOrders();
    } catch (err) {
      toast.error('Failed to update status');
    } finally {
      setUpdating(null);
    }
  };

  return (
    <AdminLayout title="Orders Management">
      <div style={{ display: 'flex', gap: '12px', marginBottom: '16px', flexWrap: 'wrap' }}>
        {STATUSES.map(s => (
          <button key={s} className={`btn btn-sm ${filterStatus === s ? 'btn-primary' : 'btn-outline'}`} onClick={() => setFilterStatus(s)}>
            {s || 'All Orders'}
          </button>
        ))}
      </div>

      {loading ? <div className="loading"><div className="spinner"></div></div> : (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Order ID</th><th>Customer</th><th>Total</th><th>Payment</th><th>Status</th><th>Date</th><th>Update Status</th></tr>
            </thead>
            <tbody>
              {orders.length === 0 && <tr><td colSpan="7" style={{ textAlign: 'center', color: '#6c757d' }}>No orders found</td></tr>}
              {orders.map(order => (
                <tr key={order._id}>
                  <td><strong>#{order._id.slice(-6).toUpperCase()}</strong></td>
                  <td>
                    <div>{order.user?.name}</div>
                    <div style={{ fontSize: '12px', color: '#6c757d' }}>{order.user?.email}</div>
                  </td>
                  <td><strong>₹{order.totalPrice?.toFixed(2)}</strong></td>
                  <td>
                    <div style={{ fontSize: '12px' }}>{order.paymentMethod}</div>
                    <div style={{ fontSize: '11px', color: order.isPaid ? '#28a745' : '#dc3545' }}>{order.isPaid ? '✅ Paid' : '⏳ Unpaid'}</div>
                  </td>
                  <td><span className={`order-status status-${order.orderStatus?.toLowerCase()}`}>{order.orderStatus}</span></td>
                  <td style={{ fontSize: '12px', color: '#6c757d' }}>{new Date(order.createdAt).toLocaleDateString()}</td>
                  <td>
                    <select
                      className="filter-select"
                      style={{ fontSize: '12px', padding: '6px' }}
                      value={order.orderStatus}
                      disabled={order.orderStatus === 'Cancelled' || updating === order._id}
                      onChange={e => {
                        const tracking = e.target.value === 'Shipped' ? prompt('Enter tracking number (optional):') : null;
                        handleStatusUpdate(order._id, e.target.value, tracking);
                      }}
                    >
                      {['Pending', 'Processing', 'Shipped', 'Delivered', 'Cancelled'].map(s => <option key={s}>{s}</option>)}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminLayout>
  );
}
