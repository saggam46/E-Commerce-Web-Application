import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import AdminLayout from './AdminLayout';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchUsers = () => {
    setLoading(true);
    axios.get(`${API_URL}/users`).then(res => setUsers(res.data.users || [])).finally(() => setLoading(false));
  };

  useEffect(() => { fetchUsers(); }, []);

  const handleRoleChange = async (userId, role) => {
    try {
      await axios.put(`${API_URL}/users/${userId}`, { role });
      toast.success('Role updated!');
      fetchUsers();
    } catch (err) {
      toast.error('Failed to update role');
    }
  };

  const handleToggleActive = async (userId, isActive) => {
    try {
      await axios.put(`${API_URL}/users/${userId}`, { isActive: !isActive });
      toast.success(`User ${isActive ? 'deactivated' : 'activated'}!`);
      fetchUsers();
    } catch (err) {
      toast.error('Failed to update user');
    }
  };

  const handleDelete = async (userId, name) => {
    if (!window.confirm(`Delete user "${name}"? This cannot be undone.`)) return;
    try {
      await axios.delete(`${API_URL}/users/${userId}`);
      toast.success('User deleted');
      fetchUsers();
    } catch (err) {
      toast.error('Failed to delete user');
    }
  };

  return (
    <AdminLayout title="Users Management">
      <div className="table-wrapper">
        {loading ? <div className="loading"><div className="spinner"></div></div> : (
          <table>
            <thead>
              <tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {users.length === 0 && <tr><td colSpan="6" style={{ textAlign: 'center', color: '#6c757d' }}>No users found</td></tr>}
              {users.map(user => (
                <tr key={user._id}>
                  <td>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '10px' }}>
                      <div style={{ width: '32px', height: '32px', background: user.role === 'admin' ? '#ffd700' : '#e94560', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: user.role === 'admin' ? '#5a4a00' : 'white', fontWeight: '700', fontSize: '13px' }}>
                        {user.name?.[0]?.toUpperCase()}
                      </div>
                      <strong>{user.name}</strong>
                    </div>
                  </td>
                  <td style={{ color: '#6c757d', fontSize: '13px' }}>{user.email}</td>
                  <td>
                    <select
                      className="filter-select"
                      style={{ fontSize: '12px', padding: '4px 8px' }}
                      value={user.role}
                      onChange={e => handleRoleChange(user._id, e.target.value)}
                    >
                      <option value="user">User</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td>
                    <span style={{ background: user.isActive ? '#e8f5e9' : '#fde8e8', color: user.isActive ? '#28a745' : '#dc3545', padding: '3px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: '600' }}>
                      {user.isActive ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td style={{ fontSize: '13px', color: '#6c757d' }}>{new Date(user.createdAt).toLocaleDateString()}</td>
                  <td style={{ display: 'flex', gap: '6px' }}>
                    <button className="btn btn-sm btn-outline" onClick={() => handleToggleActive(user._id, user.isActive)}>
                      {user.isActive ? 'Deactivate' : 'Activate'}
                    </button>
                    <button className="btn btn-sm" style={{ background: '#dc3545', color: 'white' }} onClick={() => handleDelete(user._id, user.name)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </AdminLayout>
  );
}
