import React, { useEffect, useState } from 'react';
import axios from 'axios';
import AdminLayout from './AdminLayout';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function AdminDashboard() {
  const [stats, setStats] = useState(null);
  const [recentOrders, setRecentOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      axios.get(`${API_URL}/users/stats/overview`),
      axios.get(`${API_URL}/orders?limit=5`),
    ])
      .then(([statsRes, ordersRes]) => {
        setStats(statsRes.data.stats);
        setRecentOrders(ordersRes.data.orders || []);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <AdminLayout title="Dashboard"><div className="loading"><div className="spinner"></div></div></AdminLayout>;

  return (
    <AdminLayout title="Dashboard">
      {/* Stats */}
      <div className="stats-grid">
        {[
          { label: 'Total Users', value: stats?.totalUsers || 0, icon: '👥', color: '#4CAF50' },
          { label: 'Products', value: stats?.totalProducts || 0, icon: '📦', color: '#2196F3' },
          { label: 'Total Orders', value: stats?.totalOrders || 0, icon: '🛒', color: '#FF9800' },
          { label: 'Revenue', value: `₹${(stats?.totalRevenue || 0).toLocaleString()}`, icon: '💰', color: '#e94560' },
        ].map(s => (
          <div key={s.label} className="stat-card" style={{ borderLeft: `4px solid ${s.color}` }}>
            <span className="icon">{s.icon}</span>
            <h3>{s.label}</h3>
            <div className="value" style={{ color: s.color }}>{s.value}</div>
          </div>
        ))}
      </div>

      {/* Recent Orders */}
      <div>
        <h2 style={{ fontSize: '20px', fontWeight: '800', marginBottom: '16px' }}>Recent Orders</h2>
        <div className="table-wrapper">
          <table>
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer</th>
                <th>Items</th>
                <th>Total</th>
                <th>Status</th>
                <th>Date</th>
              </tr>
            </thead>
            <tbody>
              {recentOrders.length === 0 ? (
                <tr><td colSpan="6" style={{ textAlign: 'center', color: '#6c757d' }}>No orders yet</td></tr>
              ) : recentOrders.map(order => (
                <tr key={order._id}>
                  <td><strong>#{order._id.slice(-6).toUpperCase()}</strong></td>
                  <td>{order.user?.name || 'N/A'}</td>
                  <td>{order.orderItems?.length} item(s)</td>
                  <td><strong>₹{order.totalPrice?.toFixed(2)}</strong></td>
                  <td><span className={`order-status status-${order.orderStatus?.toLowerCase()}`}>{order.orderStatus}</span></td>
                  <td style={{ fontSize: '13px', color: '#6c757d' }}>{new Date(order.createdAt).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AdminLayout>
  );
}
