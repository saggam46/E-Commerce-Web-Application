import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const s = {
  page: { minHeight: '100vh', background: '#f5f5f5', display: 'flex', alignItems: 'center', justifyContent: 'center' },
  card: { background: '#fff', padding: '2.5rem', borderRadius: '16px', width: '100%', maxWidth: '420px', boxShadow: '0 4px 24px rgba(0,0,0,0.1)' },
  title: { textAlign: 'center', fontSize: '1.5rem', fontWeight: 'bold', marginBottom: '0.5rem' },
  sub: { textAlign: 'center', color: '#888', marginBottom: '2rem', fontSize: '0.9rem' },
  label: { display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '0.85rem', color: '#555' },
  input: { width: '100%', padding: '11px', border: '1px solid #ddd', borderRadius: '8px', marginBottom: '1rem', fontSize: '0.95rem' },
  btn: { width: '100%', padding: '13px', background: '#e94560', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', fontSize: '1rem', cursor: 'pointer' },
  footer: { textAlign: 'center', marginTop: '1.5rem', color: '#888', fontSize: '0.9rem' }
};

export default function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', confirm: '' });
  const [error, setError] = useState('');

  const handleSubmit = async () => {
    if (form.password !== form.confirm) return setError('Passwords do not match');
    try {
      await register(form.name, form.email, form.password);
      navigate('/');
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div style={s.page}>
      <div style={s.card}>
        <h1 style={s.title}>Create Account</h1>
        <p style={s.sub}>Join ShopZone today</p>
        {['name','email','password','confirm'].map(field => (
          <div key={field}>
            <label style={s.label}>{field === 'confirm' ? 'Confirm Password' : field.charAt(0).toUpperCase() + field.slice(1)}</label>
            <input style={s.input} type={field.includes('password') || field === 'confirm' ? 'password' : field === 'email' ? 'email' : 'text'}
              value={form[field]} onChange={e => setForm({...form, [field]: e.target.value})} />
          </div>
        ))}
        {error && <p style={{ color: 'red', fontSize: '0.85rem', marginBottom: '1rem' }}>{error}</p>}
        <button style={s.btn} onClick={handleSubmit}>Create Account</button>
        <p style={s.footer}>Already have an account? <Link to="/login" style={{ color: '#e94560' }}>Sign In</Link></p>
      </div>
    </div>
  );
}
