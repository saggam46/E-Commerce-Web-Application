import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useCart } from '../context/CartContext';

const s = {
  container: { maxWidth: '900px', margin: '2rem auto', padding: '0 2rem' },
  title: { fontSize: '1.8rem', fontWeight: 'bold', marginBottom: '2rem' },
  grid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' },
  card: { background: '#fff', padding: '1.5rem', borderRadius: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.08)' },
  label: { display: 'block', marginBottom: '4px', fontWeight: '600', fontSize: '0.85rem', color: '#555' },
  input: { width: '100%', padding: '10px', border: '1px solid #ddd', borderRadius: '6px', marginBottom: '1rem', fontSize: '0.95rem' },
  btn: { width: '100%', padding: '13px', background: '#e94560', color: '#fff', border: 'none', borderRadius: '8px', fontWeight: 'bold', fontSize: '1rem', cursor: 'pointer', marginTop: '1rem' },
  item: { display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid #eee', fontSize: '0.9rem' },
  total: { display: 'flex', justifyContent: 'space-between', fontWeight: 'bold', fontSize: '1.1rem', marginTop: '1rem' }
};

export default function CheckoutPage() {
  const { cart, totalPrice, clearCart } = useCart();
  const navigate = useNavigate();
  const shipping = totalPrice > 500 ? 0 : 50;
  const tax = Math.round(totalPrice * 0.18);
  const [form, setForm] = useState({ street: '', city: '', state: '', zip: '', country: 'India' });
  const [paymentMethod, setPaymentMethod] = useState('COD');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleChange = e => setForm({ ...form, [e.target.name]: e.target.value });

  const placeOrder = async () => {
    if (!form.street || !form.city || !form.zip) return setError('Please fill all required fields.');
    setLoading(true);
    try {
      const { data } = await axios.post('/api/orders', {
        items: cart,
        shippingAddress: form,
        paymentMethod
      });
      clearCart();
      navigate(`/orders`);
    } catch (err) {
      setError(err.response?.data?.message || 'Order failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={s.container}>
      <h1 style={s.title}>Checkout</h1>
      <div style={s.grid}>
        <div>
          <div style={s.card}>
            <h2 style={{ marginBottom: '1.2rem' }}>Shipping Address</h2>
            {['street','city','state','zip','country'].map(field => (
              <div key={field}>
                <label style={s.label}>{field.charAt(0).toUpperCase() + field.slice(1)} {['street','city','zip','country'].includes(field) && '*'}</label>
                <input style={s.input} name={field} value={form[field]} onChange={handleChange} placeholder={field} />
              </div>
            ))}
            <h2 style={{ marginBottom: '1rem' }}>Payment Method</h2>
            {['COD', 'Card', 'UPI'].map(m => (
              <label key={m} style={{ display: 'block', marginBottom: '8px', cursor: 'pointer' }}>
                <input type="radio" name="payment" value={m} checked={paymentMethod === m}
                  onChange={() => setPaymentMethod(m)} style={{ marginRight: '8px' }} />{m === 'COD' ? 'Cash on Delivery' : m}
              </label>
            ))}
          </div>
        </div>
        <div>
          <div style={s.card}>
            <h2 style={{ marginBottom: '1.2rem' }}>Order Summary</h2>
            {cart.map(i => (
              <div key={i.product} style={s.item}>
                <span>{i.name} x{i.quantity}</span>
                <span>₹{(i.price * i.quantity).toLocaleString()}</span>
              </div>
            ))}
            <div style={{ ...s.item, borderBottom: 'none' }}><span>Subtotal</span><span>₹{totalPrice.toLocaleString()}</span></div>
            <div style={{ ...s.item, borderBottom: 'none' }}><span>Shipping</span><span>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
            <div style={{ ...s.item, borderBottom: 'none' }}><span>GST (18%)</span><span>₹{tax.toLocaleString()}</span></div>
            <div style={s.total}><span>Total</span><span>₹{(totalPrice + shipping + tax).toLocaleString()}</span></div>
            {error && <p style={{ color: 'red', marginTop: '1rem', fontSize: '0.85rem' }}>{error}</p>}
            <button style={{ ...s.btn, opacity: loading ? 0.7 : 1 }} onClick={placeOrder} disabled={loading}>
              {loading ? 'Placing Order...' : 'Place Order ✓'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
