import React from 'react';
import { Link } from 'react-router-dom';

const s = {
  hero: { background: 'linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%)', color: '#fff', padding: '80px 2rem', textAlign: 'center' },
  h1: { fontSize: '3rem', marginBottom: '1rem', fontWeight: 'bold' },
  sub: { fontSize: '1.2rem', color: '#aaa', marginBottom: '2rem' },
  btn: { background: '#e94560', color: '#fff', border: 'none', padding: '14px 36px', borderRadius: '8px', fontSize: '1.1rem', fontWeight: 'bold' },
  features: { display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))', gap: '2rem', padding: '4rem 2rem', maxWidth: '1100px', margin: '0 auto' },
  featureCard: { textAlign: 'center', padding: '2rem', background: '#fff', borderRadius: '12px', boxShadow: '0 2px 12px rgba(0,0,0,0.07)' },
  icon: { fontSize: '2.5rem', marginBottom: '1rem' },
  featureTitle: { fontWeight: 'bold', marginBottom: '8px' },
  featureText: { color: '#666', fontSize: '0.9rem' }
};

export default function HomePage() {
  return (
    <div>
      <div style={s.hero}>
        <h1 style={s.h1}>Welcome to <span style={{ color: '#e94560' }}>ShopZone</span></h1>
        <p style={s.sub}>Discover amazing products at unbeatable prices</p>
        <Link to="/products"><button style={s.btn}>Shop Now →</button></Link>
      </div>
      <div style={s.features}>
        {[
          { icon: '🚚', title: 'Free Shipping', text: 'On orders above ₹500' },
          { icon: '🔒', title: 'Secure Payment', text: 'Multiple payment options' },
          { icon: '↩️', title: 'Easy Returns', text: '30-day return policy' },
          { icon: '🎧', title: '24/7 Support', text: 'Always here to help' }
        ].map(f => (
          <div key={f.title} style={s.featureCard}>
            <div style={s.icon}>{f.icon}</div>
            <div style={s.featureTitle}>{f.title}</div>
            <div style={s.featureText}>{f.text}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
