import React, { useState } from 'react';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

export default function Profile() {
  const { user } = useAuth();
  const [profile, setProfile] = useState({ name: user?.name || '', phone: user?.phone || '' });
  const [password, setPassword] = useState({ currentPassword: '', newPassword: '', confirm: '' });
  const [saving, setSaving] = useState(false);

  const handleProfile = async (e) => {
    e.preventDefault();
    setSaving(true);
    try {
      await axios.put(`${API_URL}/auth/profile`, profile);
      toast.success('Profile updated!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update');
    } finally {
      setSaving(false);
    }
  };

  const handlePassword = async (e) => {
    e.preventDefault();
    if (password.newPassword !== password.confirm) { toast.error('Passwords do not match'); return; }
    try {
      await axios.put(`${API_URL}/auth/password`, { currentPassword: password.currentPassword, newPassword: password.newPassword });
      toast.success('Password updated!');
      setPassword({ currentPassword: '', newPassword: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to update password');
    }
  };

  return (
    <div className="container" style={{ padding: '40px 20px', maxWidth: '700px' }}>
      <div className="page-header"><h1>My Profile</h1></div>

      {/* Profile Info */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '20px', background: 'white', padding: '24px', borderRadius: '12px', boxShadow: '0 2px 10px rgba(0,0,0,0.05)', marginBottom: '28px' }}>
        <div style={{ width: '70px', height: '70px', background: '#e94560', borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '28px', fontWeight: '900', color: 'white' }}>
          {user?.name?.[0]?.toUpperCase()}
        </div>
        <div>
          <div style={{ fontWeight: '800', fontSize: '20px' }}>{user?.name}</div>
          <div style={{ color: '#6c757d' }}>{user?.email}</div>
          <span style={{ background: user?.role === 'admin' ? '#ffd700' : '#e3f2fd', color: user?.role === 'admin' ? '#5a4a00' : '#1565c0', padding: '2px 10px', borderRadius: '20px', fontSize: '12px', fontWeight: '700' }}>
            {user?.role?.toUpperCase()}
          </span>
        </div>
      </div>

      {/* Edit Profile */}
      <div className="card" style={{ padding: '24px', marginBottom: '20px' }}>
        <h3 style={{ marginBottom: '20px', fontWeight: '700' }}>Edit Profile</h3>
        <form onSubmit={handleProfile}>
          <div className="form-group">
            <label className="form-label">Full Name</label>
            <input className="form-control" value={profile.name} onChange={e => setProfile(p => ({ ...p, name: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Email (cannot change)</label>
            <input className="form-control" value={user?.email} disabled style={{ background: '#f8f9fa' }} />
          </div>
          <div className="form-group">
            <label className="form-label">Phone Number</label>
            <input className="form-control" placeholder="10-digit mobile number" value={profile.phone} onChange={e => setProfile(p => ({ ...p, phone: e.target.value }))} />
          </div>
          <button type="submit" className="btn btn-primary" disabled={saving}>{saving ? 'Saving...' : 'Save Changes'}</button>
        </form>
      </div>

      {/* Change Password */}
      <div className="card" style={{ padding: '24px' }}>
        <h3 style={{ marginBottom: '20px', fontWeight: '700' }}>Change Password</h3>
        <form onSubmit={handlePassword}>
          <div className="form-group">
            <label className="form-label">Current Password</label>
            <input type="password" className="form-control" required value={password.currentPassword} onChange={e => setPassword(p => ({ ...p, currentPassword: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">New Password</label>
            <input type="password" className="form-control" required value={password.newPassword} onChange={e => setPassword(p => ({ ...p, newPassword: e.target.value }))} />
          </div>
          <div className="form-group">
            <label className="form-label">Confirm New Password</label>
            <input type="password" className="form-control" required value={password.confirm} onChange={e => setPassword(p => ({ ...p, confirm: e.target.value }))} />
          </div>
          <button type="submit" className="btn btn-primary">Update Password</button>
        </form>
      </div>
    </div>
  );
}
