import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { toast } from 'react-toastify';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

const EMOJI_MAP = { 'Electronics': '📱', 'Clothing': '👕', 'Books': '📚', 'Home & Kitchen': '🍳', 'Sports': '⚽', 'Beauty': '💄', 'Toys': '🧸', 'Other': '📦' };

export default function ProductDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { addToCart } = useCart();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const [review, setReview] = useState({ rating: 5, comment: '' });
  const [addingToCart, setAddingToCart] = useState(false);

  useEffect(() => {
    axios.get(`${API_URL}/products/${id}`)
      .then(res => setProduct(res.data.product))
      .catch(() => navigate('/products'))
      .finally(() => setLoading(false));
  }, [id]);

  const handleAddToCart = async () => {
    if (!user) { navigate('/login'); return; }
    setAddingToCart(true);
    try {
      await addToCart(product._id, qty);
      toast.success('Added to cart!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to add to cart');
    } finally {
      setAddingToCart(false);
    }
  };

  const handleReview = async (e) => {
    e.preventDefault();
    try {
      await axios.post(`${API_URL}/products/${id}/reviews`, review);
      toast.success('Review submitted!');
      const res = await axios.get(`${API_URL}/products/${id}`);
      setProduct(res.data.product);
      setReview({ rating: 5, comment: '' });
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to submit review');
    }
  };

  if (loading) return <div className="loading"><div className="spinner"></div></div>;
  if (!product) return null;

  return (
    <div className="container" style={{ padding: '40px 20px' }}>
      <button onClick={() => navigate(-1)} className="btn btn-outline btn-sm" style={{ marginBottom: '24px' }}>← Back</button>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '48px', marginBottom: '48px' }}>
        {/* Product Image */}
        <div style={{ background: '#f8f9fa', borderRadius: '16px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '120px', height: '400px' }}>
          {EMOJI_MAP[product.category] || '📦'}
        </div>

        {/* Product Info */}
        <div>
          <div style={{ fontSize: '12px', color: '#6c757d', textTransform: 'uppercase', fontWeight: '700', letterSpacing: '1px', marginBottom: '8px' }}>
            {product.brand} · {product.category}
          </div>
          <h1 style={{ fontSize: '28px', fontWeight: '900', marginBottom: '12px' }}>{product.name}</h1>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '20px' }}>
            <span style={{ color: '#ffc107', fontSize: '18px' }}>{'⭐'.repeat(Math.round(product.ratings))}</span>
            <span style={{ color: '#6c757d', fontSize: '14px' }}>{product.ratings?.toFixed(1)} ({product.numReviews} reviews)</span>
          </div>
          <div style={{ fontSize: '36px', fontWeight: '900', color: '#e94560', marginBottom: '20px' }}>
            ₹{product.price?.toLocaleString()}
          </div>
          <p style={{ color: '#495057', lineHeight: '1.7', marginBottom: '24px' }}>{product.description}</p>

          <div style={{ marginBottom: '24px' }}>
            <span className={`product-card-badge ${product.stock === 0 ? 'out' : ''}`} style={{ fontSize: '13px', padding: '6px 14px' }}>
              {product.stock > 0 ? `✅ In Stock (${product.stock} available)` : '❌ Out of Stock'}
            </span>
          </div>

          {product.stock > 0 && (
            <div style={{ display: 'flex', gap: '16px', alignItems: 'center', marginBottom: '24px' }}>
              <div className="quantity-control">
                <button className="qty-btn" onClick={() => setQty(q => Math.max(1, q - 1))}>−</button>
                <span style={{ fontWeight: '700', minWidth: '30px', textAlign: 'center' }}>{qty}</span>
                <button className="qty-btn" onClick={() => setQty(q => Math.min(product.stock, q + 1))}>+</button>
              </div>
              <button className="btn btn-primary btn-lg" onClick={handleAddToCart} disabled={addingToCart}>
                {addingToCart ? 'Adding...' : '🛒 Add to Cart'}
              </button>
            </div>
          )}

          <button className="btn btn-secondary" onClick={() => { handleAddToCart(); navigate('/checkout'); }}>
            ⚡ Buy Now
          </button>
        </div>
      </div>

      {/* Reviews */}
      <div>
        <h2 style={{ fontSize: '22px', fontWeight: '800', marginBottom: '24px' }}>Customer Reviews</h2>

        {product.reviews?.length === 0 && <p style={{ color: '#6c757d', marginBottom: '24px' }}>No reviews yet. Be the first!</p>}

        <div style={{ marginBottom: '32px' }}>
          {product.reviews?.map(r => (
            <div key={r._id} style={{ background: 'white', padding: '20px', borderRadius: '10px', marginBottom: '12px', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <strong>{r.name}</strong>
                <span style={{ color: '#ffc107' }}>{'⭐'.repeat(r.rating)}</span>
              </div>
              <p style={{ color: '#495057', fontSize: '14px' }}>{r.comment}</p>
              <div style={{ fontSize: '12px', color: '#aaa', marginTop: '8px' }}>{new Date(r.createdAt).toLocaleDateString()}</div>
            </div>
          ))}
        </div>

        {user && (
          <div style={{ background: 'white', padding: '24px', borderRadius: '12px', boxShadow: '0 2px 10px rgba(0,0,0,0.05)' }}>
            <h3 style={{ marginBottom: '16px' }}>Write a Review</h3>
            <form onSubmit={handleReview}>
              <div className="form-group">
                <label className="form-label">Rating</label>
                <select className="form-control" value={review.rating} onChange={e => setReview(r => ({ ...r, rating: Number(e.target.value) }))}>
                  {[5,4,3,2,1].map(n => <option key={n} value={n}>{n} Star{n > 1 ? 's' : ''}</option>)}
                </select>
              </div>
              <div className="form-group">
                <label className="form-label">Comment</label>
                <textarea className="form-control" rows="4" required placeholder="Share your experience..." value={review.comment} onChange={e => setReview(r => ({ ...r, comment: e.target.value }))} />
              </div>
              <button type="submit" className="btn btn-primary">Submit Review</button>
            </form>
          </div>
        )}
      </div>
    </div>
  );
}
