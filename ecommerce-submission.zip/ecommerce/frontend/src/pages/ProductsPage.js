import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ProductCard from '../components/ProductCard';

const s = {
  container: { maxWidth: '1200px', margin: '0 auto', padding: '2rem' },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem', flexWrap: 'wrap', gap: '1rem' },
  h1: { fontSize: '1.8rem', fontWeight: 'bold' },
  filters: { display: 'flex', gap: '1rem', flexWrap: 'wrap' },
  input: { padding: '8px 14px', border: '1px solid #ddd', borderRadius: '6px', fontSize: '0.95rem' },
  grid: { display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))', gap: '1.5rem' },
  pagination: { display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '2rem' },
  pageBtn: { padding: '8px 14px', border: '1px solid #ddd', borderRadius: '4px', background: '#fff', cursor: 'pointer' }
};

export default function ProductsPage() {
  const [products, setProducts] = useState([]);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [keyword, setKeyword] = useState('');
  const [category, setCategory] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    axios.get(`/api/products?keyword=${keyword}&category=${category}&page=${page}`)
      .then(({ data }) => { setProducts(data.products); setPages(data.pages); })
      .finally(() => setLoading(false));
  }, [keyword, category, page]);

  const categories = ['Electronics', 'Footwear', 'Accessories', 'Kitchen', 'Sports'];

  return (
    <div style={s.container}>
      <div style={s.header}>
        <h1 style={s.h1}>All Products</h1>
        <div style={s.filters}>
          <input style={s.input} placeholder="Search products..." value={keyword}
            onChange={e => { setKeyword(e.target.value); setPage(1); }} />
          <select style={s.input} value={category} onChange={e => { setCategory(e.target.value); setPage(1); }}>
            <option value="">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>
      {loading ? <p>Loading...</p> : (
        <>
          <div style={s.grid}>
            {products.map(p => <ProductCard key={p._id} product={p} />)}
          </div>
          {pages > 1 && (
            <div style={s.pagination}>
              {Array.from({ length: pages }, (_, i) => (
                <button key={i+1} style={{ ...s.pageBtn, background: page === i+1 ? '#1a1a2e' : '#fff', color: page === i+1 ? '#fff' : '#333' }}
                  onClick={() => setPage(i+1)}>{i+1}</button>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  );
}
