import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { useCart } from '../context/CartContext';

export default function Cart() {
  const { cart, updateQuantity, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  const handleRemove = async (productId) => {
    try {
      await removeFromCart(productId);
      toast.success('Item removed');
    } catch {
      toast.error('Failed to remove item');
    }
  };

  const shipping = cart.total > 500 ? 0 : 40;
  const tax = Math.round(cart.total * 0.18 * 100) / 100;
  const grandTotal = cart.total + shipping + tax;

  if (cart.items?.length === 0) {
    return (
      <div className="container" style={{ textAlign: 'center', padding: '80px 20px' }}>
        <div style={{ fontSize: '80px', marginBottom: '24px' }}>🛒</div>
        <h2 style={{ marginBottom: '12px' }}>Your cart is empty</h2>
        <p style={{ color: '#6c757d', marginBottom: '24px' }}>Add some products to get started!</p>
        <Link to="/products" className="btn btn-primary btn-lg">Browse Products</Link>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="page-header">
        <h1>Shopping Cart</h1>
        <p>{cart.itemCount} item{cart.itemCount !== 1 ? 's' : ''}</p>
      </div>

      <div className="cart-layout">
        {/* Cart Items */}
        <div className="card" style={{ overflow: 'hidden' }}>
          {cart.items?.map(item => (
            <div key={item.product?._id} className="cart-item">
              <div style={{ width: '80px', height: '80px', background: '#f8f9fa', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '36px', flexShrink: 0 }}>📦</div>
              <div className="cart-item-info">
                <div className="cart-item-name">{item.product?.name}</div>
                <div style={{ fontSize: '13px', color: '#6c757d', marginBottom: '8px' }}>Unit price: ₹{item.product?.price?.toLocaleString()}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                  <div className="quantity-control">
                    <button className="qty-btn" onClick={() => updateQuantity(item.product?._id, item.quantity - 1)}>−</button>
                    <span style={{ fontWeight: '700', minWidth: '30px', textAlign: 'center' }}>{item.quantity}</span>
                    <button className="qty-btn" onClick={() => updateQuantity(item.product?._id, item.quantity + 1)}>+</button>
                  </div>
                  <button onClick={() => handleRemove(item.product?._id)} style={{ background: 'none', border: 'none', color: '#dc3545', cursor: 'pointer', fontSize: '18px' }}>🗑</button>
                </div>
              </div>
              <div className="cart-item-price">₹{item.subtotal?.toLocaleString()}</div>
            </div>
          ))}
          <div style={{ padding: '16px', display: 'flex', justifyContent: 'flex-end' }}>
            <button onClick={clearCart} className="btn btn-outline btn-sm" style={{ color: '#dc3545', borderColor: '#dc3545' }}>Clear Cart</button>
          </div>
        </div>

        {/* Order Summary */}
        <div className="order-summary">
          <h3>Order Summary</h3>
          <div className="summary-row"><span>Subtotal</span><span>₹{cart.total?.toLocaleString()}</span></div>
          <div className="summary-row"><span>Shipping</span><span style={{ color: shipping === 0 ? 'green' : 'inherit' }}>{shipping === 0 ? 'FREE' : `₹${shipping}`}</span></div>
          <div className="summary-row"><span>GST (18%)</span><span>₹{tax.toFixed(2)}</span></div>
          <div className="summary-row total"><span>Total</span><span>₹{grandTotal.toFixed(2)}</span></div>
          {cart.total < 500 && <p style={{ fontSize: '12px', color: '#6c757d', marginBottom: '16px' }}>Add ₹{(500 - cart.total).toFixed(2)} more for free shipping!</p>}
          <button className="btn btn-primary" style={{ width: '100%' }} onClick={() => navigate('/checkout')}>
            Proceed to Checkout →
          </button>
          <Link to="/products" className="btn btn-outline" style={{ width: '100%', marginTop: '10px', textAlign: 'center' }}>Continue Shopping</Link>
        </div>
      </div>
    </div>
  );
}
